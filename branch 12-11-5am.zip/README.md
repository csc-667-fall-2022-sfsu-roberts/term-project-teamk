# Term-project-teamk

To run the server, run the following command:

    $ cd UNO
    $ npm install
    $ npm start

# Home Page

![Home Page](Home.png)
