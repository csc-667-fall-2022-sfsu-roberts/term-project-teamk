# ERD Diagram

![alt text](ERD.png)