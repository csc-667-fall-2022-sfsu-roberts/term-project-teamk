Todays Tasks

* Select DOM elements
* Create a new element
* Add a class to an element
* Remove a class from an element

## Select DOM elements

* document.getElementById()

## Create a new element

* document.createElement()

## Add a class to an element

* element.classList.add()

## Remove a class from an element

* element.classList.remove()

