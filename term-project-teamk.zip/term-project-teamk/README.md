# Term-project-teamk

To run the server, run the following command:

    $ cd UNO
    $ npm install
    $ node ./bin/www

